						Universite INUKA
			    Projet web pour les etudiants en 2eme annees Informatiques
				     Professeur : BIEN-AIME Rony

				Nom		Prenom		Code		Vacation
				ETIENNE 	Samantha meia	33271		Median A